print("Hello Game")
